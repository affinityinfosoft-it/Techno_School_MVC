﻿namespace SchoolMVC.Reports.Academic {
    
    
    public partial class AcademicDataSet {
    }
}
